@extends('school.layouts.app')

@section('title')
Head Creation
@endsection

@section('content')
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <i class="fa fa-home"></i>
            <a href="{{ route('school.dashboard') }}">Dashboard</a>
        </li>
        <li>
            <i class="fa fa-angle-right"></i>
            <a href="{{ route('school.class.index') }}">Head Creation</a>
        </li>
        <li>
            <i class="fa fa-angle-right"></i>
            Head Creation
        </li>
    </ul>
</div>
<h3 class="page-title">
</h3>
<div class="row">
    <div class="col-md-12">
        <div class="portlet box blue">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-plus"></i> Head Creation
                </div>
            </div>
            <div class="portlet-body form">
                {{ Form::open(['route' => ['school.head.store'], 'method' => 'post', 'id' => 'addHeadForm', 'autocomplete' => 'off']) }}
                @include('school.head.form')
            </div>
            <div class="form-actions">
                <button type="submit" class="btn blue" id="btnSubmitHead">Add</button>
                <a type="button" href="{{ route('school.head.index') }}" class="btn default">Cancel</a>
            </div>
            {{ Form::close() }}
        </div>
    </div>
</div>
</div>
@endsection

@section('js')
<script>
    $(document).ready(function() {
        // Submit the form on the button click
        $(document).on('click', '#btnSubmitHead', function(e) {
            e.preventDefault();
            startLoader();

            $('span.error').empty().hide();

            // Send the Ajax request
            $.ajax({
                url: $('#addHeadForm').attr('action'),
                type: 'post',
                data: $('#addHeadForm').serialize(),
                success: function(data) {
                    show_FlashMessage(data.message);
                    window.location.href = data.redirectTo;
                }
            });
        });
    });
</script>
@endsection