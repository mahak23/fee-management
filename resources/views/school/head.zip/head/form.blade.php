<div class="form-body">
    <div class="row">
        <div class="col-md-8">
            <div class="form-group">
                {{ Form::label('head_name', 'Head Name', ['class' => 'control-label']) }}
                {{ Form::text('head_name', null, ['placeholder' => 'Head Name', 'class'=>'form-control']) }}
                <span class="error text-danger head_name"></span>
            </div>
            <div class="form-group">
                {{ Form::label('base_name', 'Base Name', ['class' => 'control-label']) }}
                {{ Form::text('base_name', null, ['placeholder' => 'Base Name', 'class'=>'form-control']) }}
                <span class="error text-danger base_name"></span>
            </div>
            <div class="form-group">
                {{ Form::label('sync', 'Sync Old/New', ['class' => 'control-label']) }}
                {{ Form::text('sync', null, ['placeholder' => 'Sync Old/New', 'class'=>'form-control']) }}
                <span class="error text-danger sync"></span>
            </div>
             <div class="form-group">
                {{ Form::label('vacation_in_consession', 'Vacation_In_Consession', ['class' => 'control-label']) }}
                {{ Form::text('vacation_in_consession', null, ['placeholder' => 'Vacation_In_Consession', 'class'=>'form-control']) }}
                <span class="error text-danger vacation_in_consession"></span>
            </div>
            <div class="form-group">
            
                {{ Form::label('editable', 'Editable', ['class' => 'control-label']) }}
                 {{ Form::radio('editable','Yes',['class' => 'radio inline']) }}
                Yes
                {{ Form::radio('editable','No',['class' => 'radio inline']) }}
                 No
            
            <span class="error text-danger editable"></span>
            </div>
            <div class="form-group">
             {{ Form::label('show_in_cert', 'Show_In_Certificate', ['class' => 'control-label']) }}
                 {{ Form::radio('show_in_cert','Yes',['class' => 'radio inline']) }}
                Yes
                {{ Form::radio('show_in_cert','No',['class' => 'radio inline']) }}
                 No
            
            <span class="error text-danger show_in_cert"></span>
            </div>
        </div>
    </div>