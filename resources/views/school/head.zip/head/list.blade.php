<table class="table table-striped table-bordered table-advance table-hover">
    <thead>
        <tr>
            <th width="10%" class="text-center">Sr. No</th>
            <th width="10%">Head Name</th>
            <th width="10%">Base Name</th>
            <th width="10%">Sync Old/New</th>
            <th width="10%">Vacation_month_consession</th>
             <th width="10%">Editable</th>
            <th width="10%">Show in Certificate</th>
             <th width="10%" class="text-center">Status</th>
            <th width="10%" class="text-center">Action</th>
        </tr>
    </thead>
    <tbody>
        @if($heads->total())
        @foreach($heads as $head)
        <tr class="trCount">
            <td class="highlight text-center">
                {{ $index++ }}
            </td>
            <td class="highlight">
                <a href="javascript:void(0);" class="viewDetails" data-href="{{ route('school.head.show', $head->id) }}">{{ $head->head_name }}</a>
            </td>
            <td class="highlight">
                {{ $head->base_name }}
            </td>
            <td class="highlight">
                {{ $head->sync }}
            </td>
            <td class="highlight">
                {{ $head->vacation_month_consession }}
            </td>
            <td class="highlight">
                {{ $head->editable }}
            </td>
            <td class="highlight">
                {{ $head->show_in_cert }}
            </td>
            <td class="highlight text-center">
                <i class="fa fa-circle changeStatus" data-value="{{ $head->status }}" title="@if($head->status == 1) Deactivate @else Activate @endif" data-href="{{ route('school.head.update', $head->id) }}" style="color: @if($head->status == 1) green @else red @endif"></i>
            </td>
            <td class="highlight text-center">
                <a type="button" href="{{ route('school.head.edit', $head->id) }}" class="btn default btn-xs purple margin-bottom-10">
                    <i class="fa fa-edit"></i> Edit
                </a>
                <a type="button" href="javascript:void(0);" data-href="{{ route('school.head.destroy', $head->id) }}" class="btn default btn-xs red margin-bottom-10 deleteRecord">
                    <i class="fa fa-trash-o"></i> Delete
                </a>
            </td>
        </tr>
        @endforeach
        @else
        <tr class="text-center">
            <td colspan="5">No records found.</td>
        </tr>
        @endif
    </tbody>
</table>

<div>
    {{ $heads->render() }}
</div>